import java.io.FileWriter;
import java.io.IOException;

public class linkedList {
		listNode listHead;
		
		public linkedList(){
			listHead= new listNode();
			listHead.next= new listNode("dummy");
		}
		
		public listNode listHead(){
			return listHead;
		}
		
		public void listInsert(listNode spot, listNode newNode){
			newNode.next= spot.next;
			spot.next= newNode;
		}
		
		public static listNode findSpot(linkedList l, String d){
			listNode spot= l.listHead.next;
			while(spot.next != null){
				if(spot.next.data.compareTo(d) > 0){
					return spot;
				}
				else if(spot.next.data.compareTo(d) == 0){
					return spot.next;
				}
				else{
					spot= spot.next;
				}
			}
			return spot;
		}
		
		public static boolean isCommonWord(listNode listHead, String data ){
			listNode current= listHead.next;
			while(current.next != null){
				if(current.data.equals(data)){
					return true;
				}
				else current= current.next;
			}
			return false;
		}
		public static void debugPrint(FileWriter wr, listNode listHead) throws IOException{
			listNode current= listHead.next;
			wr.write("listHead-->");
			while(current.next!= null){
				wr.write("("+current.data+", "+current.next.data+ ")->");
				current= current.next;
			}
			wr.write("("+current.data+",null)");
			wr.write("\n");
		}
		public static void printList(FileWriter wr, listNode listHead) throws IOException{
			listNode current = listHead.next;
			while(current.next!= null){
				wr.write(current.data+": "+current.counter+'\n');
				current= current.next;
			}
		}
		
		
	}