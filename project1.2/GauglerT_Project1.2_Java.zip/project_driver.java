import java.io.*;
import java.util.Scanner;

public class project_driver {
	public static void main(String args[]){
		linkedList commonWordList= new linkedList();
		try{
			Scanner commonWordFile = new Scanner(new FileReader(args[0]));
			FileWriter fw1 = new FileWriter(args[2]);
			while(commonWordFile.hasNext()){
				String data= commonWordFile.next();
				listNode spot= linkedList.findSpot(commonWordList,data);
				if(spot.data.equals(data)){
					spot.counter++;
				}
				else commonWordList.listInsert(spot, new listNode(data));
				fw1.write("Insert Data("+ data +")\n");
				linkedList.debugPrint(fw1,commonWordList.listHead); // commonWordList is printed after every insertion.
			} 
			commonWordFile.close();
			fw1.write("\n\n");
			
			Scanner englishWordFile = new Scanner(new FileReader(args[1]));
			int insertionCount=0;
			linkedList englishWordList= new linkedList();
			while(englishWordFile.hasNext()){
				String data= englishWordFile.next();
				if( !linkedList.isCommonWord(commonWordList.listHead,data)){
					listNode spot= linkedList.findSpot(englishWordList, data);
					if(spot.data.equals(data)){
						spot.counter++;
					}
					else{
						englishWordList.listInsert(spot, new listNode(data));
						insertionCount++;
						if(insertionCount >= 5){
							fw1.write("Insert Data("+ data +")\n");
							linkedList.debugPrint(fw1, englishWordList.listHead);
							insertionCount=0;
						}			
					}
				}
			}
			fw1.close();
			englishWordFile.close();
			if(args[3] != null){
				FileWriter fw2 = new FileWriter(args[3]);
				linkedList.printList(fw2, englishWordList.listHead);
				fw2.close();
			}
			
		}
		catch(Exception e){
			e.printStackTrace();
		}	
	}

}
