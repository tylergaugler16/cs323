
public class listNode {
	public listNode next;
	public String data;
	public int counter;
	
	public listNode(String d){
		data=d;
		next=null;
		counter=0;
	}
	public listNode(){
		data="";
		next=null;
		counter=0;
	}
	
}
