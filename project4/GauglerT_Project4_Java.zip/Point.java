
public class Point {
	int xCoordinate;
	int yCoordinate;
	int clusterID;
	double distance;
	
	public Point(int x, int y){
		xCoordinate= x;
		yCoordinate= y;
	}
	
	public Point(){
		xCoordinate=0;
		yCoordinate=0;
	}
}
