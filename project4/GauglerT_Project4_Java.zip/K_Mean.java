import java.io.FileWriter;
import java.lang.Math;

public class K_Mean {
	int K;
	Point kCentroids[];
	int numPoints;
	Point pointSet[];
	int pointSetIndex;
	int numRow;
	int numCol;
	int imageArray[][];
	
	public K_Mean(int k, int np, int nr, int nc){
		K=k;
		numPoints= np;
		numRow= nr;
		numCol=nc;
		
		pointSet= new Point[np];
		pointSetIndex=0;
		imageArray= new int[nr][];
		for(int i=0;i<nr;i++){
			imageArray[i]= new int[nr];
		}
		kCentroids= new Point[K+1];
		for(int i=1;i<=K;i++){
			kCentroids[i]= new Point(0,0);
		}
		
	}
	public void loadPointSet(Point p){
		assignLabel(p);
		pointSet[pointSetIndex]= p;
		pointSetIndex++;
	}
	
	private void assignLabel(Point p){
		p.clusterID= (pointSetIndex % K)+1;
	}
	
	public void printPointSet(String filename){
		try{
			FileWriter outputFile1 = new FileWriter(filename,true);
			outputFile1.write(K+"\n"+numPoints+"\n"+numRow+" "+numCol+"\n");
			for(int i=0;i<pointSetIndex;i++){
				outputFile1.write(pointSet[i].xCoordinate+ " "+ pointSet[i].yCoordinate+" "+pointSet[i].clusterID+"\n");
			}
			outputFile1.write("\n\n");
			outputFile1.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	public void mapPoint2Image(){
		for(int i=0;i<pointSetIndex;i++){
			imageArray[pointSet[i].xCoordinate][pointSet[i].yCoordinate]= pointSet[i].clusterID;
		}
		

	}
	
	public void displayImage(String filename){
		try{
			FileWriter outputFile2 = new FileWriter(filename,true);
			for(int row=0;row<numRow;row++){
				for(int col=0;col<numCol;col++){
					if(imageArray[row][col] > 0) outputFile2.write(imageArray[row][col]+" ");
					else outputFile2.write(" ");
				}
				outputFile2.write("\n");
			}
			outputFile2.close();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void findCentroids(String filename1, String filename2){
		for(int i=0;i<pointSetIndex;i++){
//			System.out.println(pointSet[4].yCoordinate/K);
			kCentroids[pointSet[i].clusterID].xCoordinate+= (pointSet[i].xCoordinate)/K;
			kCentroids[pointSet[i].clusterID].yCoordinate+= (pointSet[i].yCoordinate)/K;
		}
		
		for(int i=1;i<=K;i++){
			System.out.println(kCentroids[i].xCoordinate+", "+kCentroids[i].yCoordinate+"\n");
		}
		boolean ChangesOccur=false;
		while(!ChangesOccur){
			ChangesOccur=false;
			for(int i=0;i<pointSetIndex;i++){
				int min_i;
				for(int c=1;c<=K;c++){
					if(findLength(pointSet[i], c) < findLength(pointSet[i], pointSet[i].clusterID)){
						pointSet[i].clusterID= c;
						ChangesOccur=true;
					}
				}
			}
			mapPoint2Image();
			printPointSet(filename1);
			displayImage(filename2);

		}
		
	}
	
	private int findLength(Point p, int cluster_id){
		int centroidx= kCentroids[cluster_id].xCoordinate;
		int centroidy= kCentroids[cluster_id].yCoordinate;
		return (int) Math.sqrt(Math.pow(p.xCoordinate-centroidx, 2)- Math.pow(p.yCoordinate-centroidy, 2));
	}

}
