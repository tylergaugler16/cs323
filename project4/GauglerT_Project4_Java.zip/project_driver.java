import java.io.*;
import java.util.Scanner;

public class project_driver {
	public static void main(String args[]){
		K_Mean kmean = null;
		try{
			Scanner inputFile = new Scanner(new FileReader(args[0]));
		
			String data;
			int counter=1;
			int k=0;
			int numRow=0;
			int numCol=0;
			int numPoints=0;
			int x=0;
			int y=0;
			while(inputFile.hasNext()){
				data= inputFile.next();
				if(counter==1) k= Integer.parseInt(data);
				else if(counter==2) numPoints= Integer.parseInt(data);
				else if(counter==3) numRow= Integer.parseInt(data);
				else if(counter==4){
					numCol= Integer.parseInt(data);
					kmean= new K_Mean(k,numPoints,numRow,numCol);
				}
				else{
					x= Integer.parseInt(data);
					data= inputFile.next();
					y= Integer.parseInt(data);
					Point new_point= new Point(x,y);
					kmean.loadPointSet(new_point);	
				}
				counter++;
			
			}
			kmean.printPointSet(args[1]);
			kmean.mapPoint2Image();
			kmean.displayImage(args[2]);
			kmean.findCentroids(args[1], args[2]);
			inputFile.close();

			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
