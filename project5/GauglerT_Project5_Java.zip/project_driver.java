import java.io.FileReader;
import java.util.Scanner;


public class project_driver {

	public static void main(String[] args) {
		try{
			Scanner inputFile = new Scanner(new FileReader(args[0]));
			primMST prim;
			
				String data;
				int line =1;
				while(inputFile.hasNext()){
					data= inputFile.next();
					if(line==1) prim = new primMST(Integer.parseInt(data));
					else {
						int ni= Integer.parseInt(data);
						int nj= Integer.parseInt(inputFile.next());
						int edgeCost=Integer.parseInt(inputFile.next());
						edgeNode newNode= new edgeNode(ni,nj,edgeCost);
						newNode.printEdgeMethod(newNode);
						prim.edgeList.insert(prim.edgeList, newNode);
						prim.graphNodeIDArray[ni]++;
						prim.graphNodeIDArray[nj]++;
					}
					line++;
				}
				
				inputFile.close();
	
//				prim->printArray(argv[3]);
//				prim->printEdgeList(argv[3]);
//				prim->PrimsMST(argv[3]);
	
		}
		catch(Exception e){
			e.printStackTrace();
		}


	

}
