
public class edgeNode {
	int Ni;
	int Nj;
	int edgeCost;
	boolean isDeleted;
	edgeNode next;

	public edgeNode(int i, int j, int cost){
		Ni=i;
		Nj=j;
		edgeCost=cost;
		next= null;
		isDeleted=false;
	}
	public void insert(edgeNode head, edgeNode newNode){
		edgeNode current= head;
		boolean inserted=false;
		while(inserted== false && current.next != null){
			edgeNode nextNode= current.next;
			if(nextNode.next==null){
				newNode.next= nextNode.next;
				nextNode.next=newNode;
				inserted=true;
			}
			else if(nextNode.next.edgeCost >= newNode.edgeCost){
				newNode.next= nextNode.next;
				nextNode.next=newNode;
				inserted=true;
			}
			current= nextNode;
		}

	}
	public void printEdgeMethod(edgeNode node){
//		outputFile2<<"<"<<node.Ni<<", "<<node.Nj<<","<<node.edgeCost<<">"<<endl;
	}
	public edgeNode deleteEdge(edgeNode head){
//		cout<<this,getSize(head)<<endl;
		edgeNode current= head.next;
		while(current!=null){
			if(!current.isDeleted){
				return current;
			}
			current=current.next;
		}
		return null;
	}
	public void insertInFront(edgeNode head, edgeNode newNode){
		newNode.next= head.next;
		head.next= newNode;
	}
	public void printMSTofG(edgeNode head, String filename){
		edgeNode current= head.next;
//		outputFile2.open(filename,true);
//		outputFile2<<endl<<"MST of G:"<<endl;
		while(current!=null){
//			outputFile2<<"<"<<current->Ni<<", "<<current->Nj<<", "<<current->edgeCost<<" >\n";
//			current=current->next;
		}
//		outputFile2<<endl;
	}
	public int getSize(edgeNode head){
		int count=0;
		edgeNode current= head.next;
		if(current.next!=null){
			current=current.next;
			while(current!=null){
				count++;
				current=current.next;
			}
		}
		return count;
	}

}
