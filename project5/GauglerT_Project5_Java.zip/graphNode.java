import java.io.FileWriter;


public class graphNode {
	int nodeID;
	graphNode next;
	graphNode isEmpty;
	
	public graphNode(int n){
		nodeID= n;
		next=null;
	}
	
	public void insert(graphNode head, graphNode newNode){
		newNode.next=head.next;
		head.next= newNode;	
	}
	public boolean inSet(graphNode set, int id){
		graphNode current= set.next;
		while(current!=null){
			if(current.nodeID == id) return true;
			current=current.next;
		}
		return false;

	}
	public void printGraph(graphNode set, String filename, String header){
		
		try{
			if(set.next!=null){
	
				FileWriter outputFile2 = new FileWriter(filename,true);
				graphNode current= set.next;
				outputFile2.write(header);
				while(current!= null){
					outputFile2.write(current.nodeID);
					current=current.next;
				}
				outputFile2.write("\n");
				outputFile2.close();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	public void deleteNode(graphNode head, int id){
		graphNode current= head.next;
		while(current.next!=null){
			graphNode nextNode= current.next;
			if(current.next.nodeID == id){
				current.next = nextNode.next;
				return;
			}
			current= nextNode;
		}
	}
	public boolean empty(graphNode head){
		if(head.next == null) return true;
		else return false;
	}
	public int getSize(graphNode head){
		int count=0;
		graphNode current= head.next;
		if(current.next!=null){
			current=current.next;
			while(current!=null){
				count++;
				current=current.next;
			}
		}
		return count;
	}
	
}
