
public class primMST {
	int N;
	int totalCost;
	int graphNodeIDArray[];
	edgeNode edgeList;
	graphNode setA ;
	graphNode setB;
	edgeNode MSTofG;
	
	public primMST(int n){
		N=n;
		totalCost=0;
		graphNodeIDArray= new int[N];
		for(int i=0;i<N;i++){
			graphNodeIDArray[i]=0;
		}
		edgeList= new edgeNode(0,0,0);
		edgeNode dummy= new edgeNode(0,0,0);
		edgeList.next= dummy;
		setA= new graphNode(0);
		setB= new graphNode(0);
		setA.next= new graphNode(0);
		setB.next= new graphNode(0);
		MSTofG = new edgeNode(0,0,0);
		MSTofG.next = new edgeNode(0,0,0);
	}

}
