import java.io.*;
import java.util.Scanner;

public class project_1 {
	
	public static void main(String args[]){
		linkedList sortedList= new linkedList();
		
		try{
			Scanner inFile = new Scanner(new FileReader(args[0]));
			FileWriter fw = new FileWriter(args[1]);
			while(inFile.hasNext()){
				String data= inFile.next();
				listNode spot= linkedList.findSpot(sortedList,data);
				if(spot.data.equals(data)){
					spot.counter++;
				}
				else sortedList.listInsert(spot, new listNode(data));
				fw.write("Insert data("+data+")\n");
				fw.write(sortedList.printList()+"\n");
			} 
			inFile.close();
			fw.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		sortedList.printList();		
	}
}
