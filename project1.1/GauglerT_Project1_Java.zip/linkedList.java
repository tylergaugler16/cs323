
public class linkedList {
		listNode listHead;
		
		public linkedList(){
			listHead= new listNode();
			listHead.next= new listNode();
		}
		
		public listNode listHead(){
			return listHead;
		}
		
		public void listInsert(listNode spot, listNode newNode){
			newNode.next= spot.next;
			spot.next= newNode;
		}
		
		public static listNode findSpot(linkedList l, String d){
			listNode spot= l.listHead.next;
			while(spot.next != null){
				if(spot.next.data.compareTo(d) > 0){
					return spot;
				}
				else if(spot.next.data.compareTo(d) == 0){
					return spot.next;
				}
				else{
					spot= spot.next;
				}
			}
			return spot;
		}
		
		public String printList(){
			listNode current= listHead.next;
			String t="";
			while(current.next != null){
				t= t.concat(" "+current.next.data+"->");
				current= current.next;
			}
			t= t.concat("\n");
			return t;
		}
		
	}
