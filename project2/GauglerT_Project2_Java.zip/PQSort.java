import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;



public class PQSort {
	int PQArray[];

	PQSort(int size){
		PQArray= new int[size+1];
		PQArray[0]=0;
	}
	public void buildPQArray(String filename1, String filename2){
		try {
			Scanner inputFile = new Scanner(new FileReader(filename1));
			FileWriter outputFile = new FileWriter(filename2);
			String data;
			while(inputFile.hasNext()){
				data= inputFile.next();
				insertOneDataItem(Integer.parseInt(data));
				outputFile.write(PQprint()+"\n");
			}
			inputFile.close();
			outputFile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void insertOneDataItem(int value){
		int size= PQArray[0];
		PQArray[size+1]=value;
		PQArray[0]++;
		bubbleUp(size+1);
	}
	
	private void bubbleUp(int child_index){
		
		while(PQArray[child_index] < PQArray[child_index/2] ){
			if(child_index == 1)break;
			swapValues(child_index/2, child_index);
			child_index= child_index/2;
		}
			
	}
	private void swapValues(int value1, int value2){
		int temp= PQArray[value1];
		PQArray[value1]= PQArray[value2];
		PQArray[value2]= temp;
	}
	
	private String PQprint(){
		int size= (PQArray[0] < 10)? PQArray[0] : 10;
		int i=0;
		String printed_list="";
		while(i <= size){
			printed_list= printed_list.concat(PQArray[i]+" ");
			i++;
		}
		return printed_list;
	}

	public void deletePQArray(String filename1, String filename2){
		
		try {
			FileWriter outputFile1 = new FileWriter(filename1, true);
			outputFile1.write("\n\n");
			FileWriter outputFile2= new FileWriter(filename2);
			while(PQArray[0] > 0){
				outputFile1.write(PQprint() + "\n");
				System.out.println(PQprint());
				outputFile2.write(deleteRoot()+"\n");
				bubbleDown();
			}
			outputFile1.close();
			outputFile2.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private void bubbleDown(){
		int parent_index= 1;
		
		while( parent_index*2 <= PQArray[0] ){
			
			int smaller_child_index= parent_index*2;
			if( (parent_index*2)+1 <= PQArray[0] && PQArray[smaller_child_index] > PQArray[(parent_index*2)+1]){
				smaller_child_index= (parent_index*2)+1;
			}	
			if(PQArray[parent_index] > PQArray[smaller_child_index]){
				swapValues(parent_index, smaller_child_index);
				
			}else {break;}
			
			parent_index= smaller_child_index;	
		
			
		}
		
	}
	private String deleteRoot(){
		if(PQArray[0] > 0){
			int root= PQArray[1];
			int size= PQArray[0];
			PQArray[1]=PQArray[size];
			PQArray[0]--;
			return Integer.toString(root);
		}
		return "";
	}
	
}
