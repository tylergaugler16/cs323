import java.io.*;
import java.util.Scanner;

public class ProjectDriver {
	public static void main(String args []){
		
		int size=0;
			try {
				
				Scanner inputFile = new Scanner(new FileReader(args[0]));
				
				while(inputFile.hasNext()){
					inputFile.next();
					size++;
				}
				inputFile.close();
				PQSort myPriorityQueue= new PQSort(size);
				myPriorityQueue.buildPQArray(args[0],args[1]);
				myPriorityQueue.deletePQArray(args[1],args[2]);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		
		
		
	}

}
